<?php
	include("menu.html");
?>

<form action="inserir.php" method="post">
<b>Inserir novo elemento:<b><br><br>
Nome: <input type="text" name="nome"><br>
Telefone: <input type="text" name="telefone"><br>
Email: <input type="text" name="email"><br>
<input type="submit" name="adicionar" value="adicionar">
</form><hr>
