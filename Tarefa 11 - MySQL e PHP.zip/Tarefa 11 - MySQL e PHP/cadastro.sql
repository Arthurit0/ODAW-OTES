CREATE DATABASE exercicio_odaw;
USE exercicio_odaw;
CREATE TABLE exercicio11(codigo int auto_increment primary key, nome char(20), email char(30), idade int);